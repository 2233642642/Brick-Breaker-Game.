/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import java.awt.*;

public class Ball {
    public int x, y, width, height;
    private int xSpeed, ySpeed;

    public Ball(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.xSpeed = 1;
        this.ySpeed = 1;
    }

    public void move() {
        x += xSpeed;
        y += ySpeed;
    }

    public void changeXDirection() {
        xSpeed = -xSpeed;
    }

    public void changeYDirection() {
        ySpeed = -ySpeed;
    }

    public void draw(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillOval(x, y, width, height);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    public void resetPosition() {
        x = 400;
        y = 300;
    }
}
