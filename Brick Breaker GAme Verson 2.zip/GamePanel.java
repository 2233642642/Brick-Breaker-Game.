/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GamePanel extends JPanel implements KeyListener {
    private static final int PANEL_WIDTH = 800;
    private static final int PANEL_HEIGHT = 600;
    private static final int BALL_RADIUS = 20;
    private static final int PADDLE_WIDTH = 100;
    private static final int PADDLE_HEIGHT = 20;
    private static final int BRICK_WIDTH = 60;
    private static final int BRICK_HEIGHT = 20;
    private static final int NUM_BRICKS_ROWS = 5;
    private static final int NUM_BRICKS_COLS = 10;

    private Player player;
    private Ball ball;
    private Paddle paddle;
    private Brick[][] bricks;
    private int score;
    private int currentLevel;

    public GamePanel(Player player) {
        this.player = player;
        this.score = 0;
        this.currentLevel = 1;
        this.ball = new Ball(PANEL_WIDTH / 2 - BALL_RADIUS / 2, PANEL_HEIGHT / 2 - BALL_RADIUS / 2, BALL_RADIUS, BALL_RADIUS);
        this.paddle = new Paddle(PANEL_WIDTH / 2 - PADDLE_WIDTH / 2, PANEL_HEIGHT - PADDLE_HEIGHT - 20, PADDLE_WIDTH, PADDLE_HEIGHT);
        this.bricks = new Brick[NUM_BRICKS_ROWS][NUM_BRICKS_COLS];
        initializeBricks();
        setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
    }

    private void initializeBricks() {
        for (int i = 0; i < NUM_BRICKS_ROWS; i++) {
            for (int j = 0; j < NUM_BRICKS_COLS; j++) {
                bricks[i][j] = new Brick(j * (BRICK_WIDTH + 5) + 30, i * (BRICK_HEIGHT + 5) + 50, BRICK_WIDTH, BRICK_HEIGHT);
            }
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        ball.draw(g);
        paddle.draw(g);
        for (int i = 0; i < NUM_BRICKS_ROWS; i++) {
            for (int j = 0; j < NUM_BRICKS_COLS; j++) {
                if (bricks[i][j] != null && bricks[i][j].isVisible()) {
                    bricks[i][j].draw(g);
                }
            }
        }
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        g.drawString("Level: " + currentLevel, 20, 30);
        g.drawString("Score: " + score, 20, 60);
    }

    public void update() {
        ball.move();
        checkCollision();
        repaint();
    }

    private void checkCollision() {
        Rectangle ballRect = ball.getBounds();
        Rectangle paddleRect = paddle.getBounds();

        if (ballRect.intersects(paddleRect)) {
            ball.changeYDirection();
        }

        boolean bricksCleared = true;
        for (int i = 0; i < NUM_BRICKS_ROWS; i++) {
            for (int j = 0; j < NUM_BRICKS_COLS; j++) {
                if (bricks[i][j] != null && ballRect.intersects(bricks[i][j].getBounds())) {
                    bricks[i][j].setVisible(false);
                    ball.changeYDirection();
                    score += 10;
                }
                if (bricks[i][j] != null && bricks[i][j].isVisible()) {
                    bricksCleared = false;
                }
            }
        }

        if (bricksCleared) {
            advanceLevel();
        }

        if (ball.x <= 0 || ball.x >= getWidth() - ball.width) {
            ball.changeXDirection();
        }
        if (ball.y <= 0) {
            ball.changeYDirection();
        }
        if (ball.y >= getHeight()) {
            gameOver();
        }
    }

    private void advanceLevel() {
        currentLevel++;
        if (currentLevel <= 5) {
            initializeBricks();
            ball.resetPosition();
            paddle.resetPosition();
        } else {
            gameWin();
        }
    }

    private void gameWin() {
        JOptionPane.showMessageDialog(this, "Congratulations, you won! Your score: " + score);
        player.setScore(score);
        System.exit(0);
    }

    private void gameOver() {
        JOptionPane.showMessageDialog(this, "Game Over! Your score: " + score);
        player.setScore(score);
        System.exit(0);
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_LEFT) {
            paddle.moveLeft();
        } else if (key == KeyEvent.VK_RIGHT) {
            paddle.moveRight();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}
}
