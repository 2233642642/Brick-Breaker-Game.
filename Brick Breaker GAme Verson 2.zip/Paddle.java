/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import java.awt.*;

public class Paddle {
    public int x, y, width, height;
    private static final int PADDLE_SPEED = 5;

    public Paddle(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void moveLeft() {
        x -= PADDLE_SPEED;
        if (x < 0) {
            x = 0;
        }
    }

    public void moveRight() {
        x += PADDLE_SPEED;
        if (x + width > 800) {
            x = 800 - width;
        }
    }

    public void draw(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(x, y, width, height);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, width, height);
    }

    public void resetPosition() {
        x = 350;
        y = 550;
    }
}
