/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.brickbreakergameverson3;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Board extends JPanel implements ActionListener {
    private Ball ball;
    private Paddle paddle;
    private Brick[][] bricks;
    private Score score;
    private Timer timer;
    private LoginSystem loginSystem;

    public Board(LoginSystem loginSystem) {
        this.loginSystem = loginSystem;
       // ball = new Ball(400, 300, 20);
        ball = new Ball(700, 300, 40);
       // paddle = new Paddle(350, 550, 100, 20);
        paddle = new Paddle(750, 620, 150, 30);
        score = new Score();
       // bricks = new Brick[5][10];
       bricks = new Brick[3][16];
        int brickWidth = 70;
        int brickHeight = 20;

        for (int i = 0; i < bricks.length; i++) {
            for (int j = 0; j < bricks[i].length; j++) {
                bricks[i][j] = new Brick(j * (brickWidth + 10) + 30, i * (brickHeight + 10) + 50, brickWidth, brickHeight);
            }
        }

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    paddle.moveLeft();
                }
                if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    paddle.moveRight();
                }
            }
        });

        setFocusable(true);

        timer = new Timer(10, this);
        timer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ball.move();
        checkCollision();
        repaint();
    }

    private void checkCollision() {
        if (ball.getBounds().intersects(paddle.getBounds())) {
            ball.reverseYDirection();
        }

        for (int i = 0; i < bricks.length; i++) {
            for (int j = 0; j < bricks[i].length; j++) {
                Brick brick = bricks[i][j];
                if (brick.isVisible() && ball.getBounds().intersects(brick.getBounds())) {
                    ball.reverseYDirection();
                    brick.setVisible(false);
                    score.increment();
                }
            }
        }

        if (ball.getBounds().y > 600) {
            timer.stop();
            loginSystem.saveScore(score.getScore());
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        ball.draw(g);
        paddle.draw(g);
        for (int i = 0; i < bricks.length; i++) {
            for (int j = 0; j < bricks[i].length; j++) {
                bricks[i][j].draw(g);
            }
        }
        g.drawString("Score: " + score.getScore(), 10, 10);
    }
}
