/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.brickbreakergameverson3;
import javax.swing.*;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class LoginSystem {
    private static final String FILE_NAME = "players.dat";
    private Map<String, String> users;
    private String currentPlayer;

    public LoginSystem() {
        users = new HashMap<>();
        loadUsers();
    }

    public boolean login(String id, String password) {
        if (users.containsKey(id) && users.get(id).equals(password)) {
            currentPlayer = id;
            return true;
        }
        return false;
    }

    public boolean register(String id, String password) {
        if (!users.containsKey(id)) {
            users.put(id, password);
            saveUsers();
            currentPlayer = id;
            return true;
        }
        return false;
    }

    public String getCurrentPlayer() {
        return currentPlayer;
    }

    private void loadUsers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            users = (Map<String, String>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No existing user data found, starting fresh.");
        }
    }

    private void saveUsers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(users);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveScore(int score) {
        try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(currentPlayer + ".txt", true)))) {
            out.println("Score: " + score);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
