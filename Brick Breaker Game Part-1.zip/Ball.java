/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.brickbreakergameverson3;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Ball {
    private int x, y, diameter, xVelocity, yVelocity;
   // private final int SPEED = 3; // Reduced speed
    private final int SPEED = 2; // Reduced speed

    public Ball(int x, int y, int diameter) {
        this.x = x;
        this.y = y;
        this.diameter = diameter;
        this.xVelocity = SPEED;
        this.yVelocity = SPEED;
    }

    public void move() {
        x += xVelocity;
        y += yVelocity;

        if (x <= 0 || x >= 800 - diameter) {
            xVelocity = -xVelocity;
        }

        if (y <= 0) {
            yVelocity = -yVelocity;
        }
    }

    public void reverseYDirection() {
        yVelocity = -yVelocity;
    }

    public void reverseXDirection() {
        xVelocity = -xVelocity;
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, diameter, diameter);
    }

    public void draw(Graphics g) {
        g.setColor(Color.BLACK);
        g.fillOval(x, y, diameter, diameter);
    }
}
