/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.brickbreakergameverson3;
import java.awt.Color;
import javax.swing.*;

public class Game {
    private static JFrame gameFrame;
    private static Board board;
    private static LoginSystem loginSystem;

    public static void main(String[] args) {
        showLoginWindow();
    }

    private static void showLoginWindow() {
        JFrame loginFrame = new JFrame("Login System");
        loginSystem = new LoginSystem();

        JPanel loginPanel = new JPanel();
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(userField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passField);
        loginPanel.add(loginButton);
        loginPanel.add(registerButton); 
        loginFrame.add(loginPanel);
        loginFrame.setSize(1400, 1400);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setVisible(true);
        

        loginButton.addActionListener(e -> {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if (loginSystem.login(username, password)) {
                startGame();
                loginFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Login Failed");
            }
        });

        registerButton.addActionListener(e -> {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if (loginSystem.register(username, password)) {
                startGame();
                loginFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Registration Failed");
            }
        });
    }

    private static void startGame() {
        gameFrame = new JFrame();
        board = new Board(loginSystem);

        gameFrame.setTitle("Brick Breaker Game");
        gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gameFrame.setSize(1400, 1400);
        gameFrame.add(board);
        gameFrame.setVisible(true);
    }

    public static void showScoreHistory() {
        JFrame historyFrame = new JFrame("Score History");
        JTextArea historyArea = new JTextArea(20, 40);
        historyArea.setText(loginSystem.getScoreHistory());
        historyArea.setEditable(false);

        JButton restartButton = new JButton("Restart Game");
        restartButton.addActionListener(e -> {
            historyFrame.dispose();
            gameFrame.dispose();
            startGame();
        });

        JPanel panel = new JPanel();
        panel.add(new JScrollPane(historyArea));
        panel.add(restartButton);

        historyFrame.add(panel);
        historyFrame.pack();
        historyFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        historyFrame.setVisible(true);
    }
}
