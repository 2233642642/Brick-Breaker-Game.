/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.brickbreakergameverson3;
import java.awt.Color;
import javax.swing.*;

public class Game {
    public static void main(String[] args) {
        JFrame loginFrame = new JFrame("Login System");
        LoginSystem loginSystem = new LoginSystem();

        JPanel loginPanel = new JPanel();
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);
        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(userField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passField);
        loginPanel.add(loginButton);
        loginPanel.add(registerButton);

        loginFrame.add(loginPanel);
        loginFrame.setSize(300, 150);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setVisible(true);

        loginButton.addActionListener(e -> {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if (loginSystem.login(username, password)) {
                startGame(loginSystem);
                loginFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Login Failed");
            }
        });

        registerButton.addActionListener(e -> {
            String username = userField.getText();
            String password = new String(passField.getPassword());
            if (loginSystem.register(username, password)) {
                startGame(loginSystem);
                loginFrame.dispose();
            } else {
                JOptionPane.showMessageDialog(loginFrame, "Registration Failed");
            }
        });
    }

    private static void startGame(LoginSystem loginSystem) {
        JFrame frame = new JFrame();
        Board board = new Board(loginSystem);

        frame.setTitle("Brick Breaker Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1500, 1000);
        frame.add(board);
        frame.setVisible(true);
        
    }
}
