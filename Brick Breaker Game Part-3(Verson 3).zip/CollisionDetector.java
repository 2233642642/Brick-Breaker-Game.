/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.brickbreakergameverson3;

import java.awt.Rectangle;

public class CollisionDetector {
    public static boolean isColliding(Rectangle r1, Rectangle r2) {
        return r1.intersects(r2);
    }
}
